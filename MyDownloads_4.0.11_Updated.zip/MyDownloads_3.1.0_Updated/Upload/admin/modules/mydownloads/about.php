<?php
/***************************************************************************
 *
 *   MyDownloads plugin - About Module
 *   Version 4.0.11
 *
 ***************************************************************************/

if(!defined("IN_MYBB"))
{
	die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
}

$lang->load("mydownloads");

$page->add_breadcrumb_item(isset($lang->nav_about) ? $lang->nav_about : "About", "index.php?module=mydownloads-about");
$page->output_header(isset($lang->nav_about) ? $lang->nav_about : "About");

$release_date = "23 October 2026, 12:41 WIB";
$next_update  = "23 October 2026, 12:41 WIB";

$table = new Table;
$table->construct_header("MyDownloads — Downloads system for MyBB", array("colspan" => 2));

$table->construct_cell("<strong>Version</strong>", array("width" => "30%", "class" => "align_center"));
$table->construct_cell("4.0.11");
$table->construct_row();

$table->construct_cell("<strong>PHP</strong>", array("class" => "align_center"));
$table->construct_cell("8.0+");
$table->construct_row();

$table->construct_cell("<strong>MyBB</strong>", array("class" => "align_center"));
$table->construct_cell("1.8.x (compatible)");
$table->construct_row();

$table->construct_cell("<strong>Release</strong>", array("class" => "align_center"));
$table->construct_cell($release_date);
$table->construct_row();

$table->construct_cell("<strong>Next Update</strong>", array("class" => "align_center"));
$table->construct_cell($next_update);
$table->construct_row();

$log_html = ''
	. '<div style="text-align:left;line-height:1.55;font-size:12px;max-height:280px;overflow-y:auto;overflow-x:hidden;padding:6px 10px;border:1px solid #ccc;background:#fafafa;border-radius:3px;">'
	. '<strong>v4.0.11 (23 Oct 2026, 12:41 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Payment mode: added Free option (disable Points and/or PayPal)<br />'
	. '2. Dropdown shows even if only Points or only PayPal is available<br /><br />'
	. '<strong>v4.0.10 (23 Oct 2026, 12:32 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Fixed SQL error on Submit Download when cid empty/missing<br />'
	. '2. Always initialize $cid and $download on submit form<br />'
	. '3. Guard category/tags queries if tables missing<br /><br />'
	. '<strong>v4.0.9 (23 Oct 2026, 11:47 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Submit/Edit: Payment method dropdown (Points only / PayPal only / Both)<br />'
	. '2. Frontend-only — ACP global settings unchanged<br />'
	. '3. JS toggles fields; POST forces price or points to 0 per selection<br /><br />'
	. '<strong>v4.0.8 (24 Sep 2026, 11:51 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Multi preview image upload on Submit (up to 10 files)<br />'
	. '2. First image = cover/thumbnail · rest available in slider<br />'
	. '3. Client-side + server-side max 10 limit to protect disk space<br /><br />'
	. '<strong>v4.0.7 (24 Sep 2026, 09:34 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Latest Builds moved above License section<br />'
	. '2. Edit / Delete per build (owner & mods) — dedicated pages<br />'
	. '3. Thumbnail → image slider with fullscreen, zoom, close, arrows<br /><br />'
	. '<strong>v4.0.6 (24 Sep 2026, 09:10 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Fixed HTTP 500 on Manage Previews (undefined INPUT_INT constant on PHP 8)<br />'
	. '2. Safe unserialize for preview field (all paths)<br />'
	. '3. Path traversal hardening on historical build downloads<br />'
	. '4. Fixed undefined $attachment in preview upload error handler<br /><br />'
	. '<strong>v4.0.5 (24 Sep 2026, 01:29 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. PayPal checkout hidden when price is 0 (fixed string vs number comparison)<br />'
	. '2. Update status badge restyled for dark themes (no harsh white box)<br />'
	. '3. NEW: Latest Builds panel (MyBB.com style) — STABLE badge, version, build #, date<br />'
	. '4. Historical builds downloadable via download_build (keeps old files on update)<br /><br />'
	. '<strong>v4.0.4 (24 Sep 2026, 01:05 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Fixed duplicate Enable PayPal checkbox on submit/edit forms<br />'
	. '2. NEW: Download update history log (frontend)<br />'
	. '&nbsp;&nbsp;&nbsp;- Table mydownloads_updates stores version / file / notes / date / user<br />'
	. '&nbsp;&nbsp;&nbsp;- Edit form: "Log as update" checkbox + optional notes (no re-upload required)<br />'
	. '&nbsp;&nbsp;&nbsp;- Auto-log when a new file is uploaded on edit<br />'
	. '&nbsp;&nbsp;&nbsp;- View page shows Update: Yes/No + expandable history<br /><br />'
	. '<strong>v4.0.3 (23 Sep 2026, 22:26 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. Per-submission PayPal Enable/Disable checkbox on Submit &amp; Edit forms<br />'
	. '2. When unchecked: price forced to 0 and PayPal email cleared (free download)<br />'
	. '3. Price &amp; PayPal email fields show/hide via JS when toggle changes<br />'
	. '4. Works without re-installing templates (inline HTML fallback)<br /><br />'
	. '<strong>v4.0.2 (23 Sep 2026, 20:51 WIB) — Maintenance by Terzier</strong><br /><br />'
	. '1. CRITICAL: Fixed blank/white admin pages caused by unguarded THIS_SCRIPT constant (PHP 8 fatal)<br />'
	. '2. Guarded all THIS_SCRIPT checks with defined()<br />'
	. '3. Fixed missing global $mybb in mydownloads_json_error()<br />'
	. '4. Hardened mydownloads_admin_quick_access() against missing lang keys / DB<br />'
	. '5. About page: Next Update timestamp + scrollable Log Editing panel<br /><br />'
	. '<strong>v4.0.1 (23 Sep 2026) — Maintenance by Terzier</strong><br /><br />'
	. '1. Fixed HTTP ERROR 500 when submitting a download/file (PHP 8 undefined array keys &amp; undefined $pid)<br />'
	. '2. Safe isset() for all $submission keys in submit/approve functions<br />'
	. '3. Safe $_FILES and $mybb-&gt;input access on submit path<br />'
	. '4. Correct unlink of uploaded file on preview validation failure<br />'
	. '5. upload_attachment() always returns consistent array including error key<br /><br />'
	. '<strong>v4.0 (20 Sep 2026) — Maintenance by Terzier</strong><br /><br />'
	. '1. Compatibility: MyBB 1.8.x latest + PHP 8.0 / 8.1 / 8.2 / 8.3 / 8.4<br />'
	. '2. Added About page (first menu item) with credits &amp; version info<br />'
	. '3. Added Backup &amp; Restore (ACP → MyDownloads → Backup &amp; Restore)<br />'
	. '&nbsp;&nbsp;&nbsp;- Backup SQL: Categories, Log, Submissions, PayPal Logs, Reported Items, Tags<br />'
	. '&nbsp;&nbsp;&nbsp;- (+ related tables: downloads, comments, ratings)<br />'
	. '&nbsp;&nbsp;&nbsp;- Restore from .sql with confirmation (type YES)<br />'
	. '&nbsp;&nbsp;&nbsp;- Safe mode: hide_errors so failed query does not cause HTTP 500<br />'
	. '4. PHP 8 safety fixes:<br />'
	. '&nbsp;&nbsp;&nbsp;- Guard isset() on $_FILES access (submit/upload)<br />'
	. '&nbsp;&nbsp;&nbsp;- Initialize $download_file / $ret arrays<br />'
	. '&nbsp;&nbsp;&nbsp;- Initialize $newpoints_installed = false (fix blank white ACP pages)<br />'
	. '&nbsp;&nbsp;&nbsp;- mydownloads_getMime() empty URL + no-cURL fallback<br />'
	. '&nbsp;&nbsp;&nbsp;- Banner validation only runs when banner is not empty<br />'
	. '5. About page styled with standard MyBB ACP Table (thead/trow)<br />'
	. '6. Menu order: About → Categories/Downloads → Log → Submissions → PayPal Logs → Reported Items → Tags → Backup &amp; Restore<br />'
	. '7. Responsive helper CSS: Upload/css/mydownloads_responsive.css (optional)<br />'
	. '8. Language strings updated (nav_about, nav_backup, permissions)<br />'
	. '9. Added voluntary PayPal donation button (default $25, amount editable)<br />'
	. '</div>';

$table->construct_cell("<strong>Log Editing</strong>", array("class" => "align_center", "valign" => "top"));
$table->construct_cell($log_html);
$table->construct_row();

$table->output("About");

echo "<br />";

$table2 = new Table;
$table2->construct_header("Credit", array("colspan" => 2));

$table2->construct_cell("<strong>Creator</strong>", array("width" => "30%", "class" => "align_center"));
$table2->construct_cell('<a href="https://community.mybb.com/user-8582.html" target="_blank" rel="noopener">Diogo Parrinha</a>');
$table2->construct_row();

$table2->construct_cell("<strong>Maintenance</strong>", array("class" => "align_center"));
$table2->construct_cell('<a href="https://community.mybb.com/user-22201.html" target="_blank" rel="noopener">Terzier</a>');
$table2->construct_row();

$table2->output("Credit");

echo "<br />";

// Voluntary PayPal donation
$table3 = new Table;
$table3->construct_header("Support the Maintainer (Voluntary Donation)", array("colspan" => 2));

$donate_html = '
<div style="text-align:left;line-height:1.6;padding:4px 0;">
	<p style="margin:0 0 10px 0;">If this update helped you, a voluntary donation is appreciated. Amount is free to edit (default <strong>$25</strong>).</p>
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank" style="margin:0;">
		<input type="hidden" name="cmd" value="_donations" />
		<input type="hidden" name="business" value="terziersampurno@gmail.com" />
		<input type="hidden" name="item_name" value="MyDownloads 4.0.11 — Maintenance Support (Terzier)" />
		<input type="hidden" name="currency_code" value="USD" />
		<label for="md_donate_amount"><strong>Amount (USD):</strong></label>
		<input type="number" id="md_donate_amount" name="amount" value="25" min="1" step="0.01" style="width:90px;margin:0 8px;padding:4px 6px;" />
		<input type="hidden" name="no_shipping" value="1" />
		<input type="hidden" name="no_note" value="0" />
		<input type="hidden" name="bn" value="PP-DonationsBF:btn_donate_LG.gif:NonHostedGuest" />
		<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="Donate with PayPal" style="vertical-align:middle;" />
		<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1" />
	</form>
	<p style="margin:10px 0 0 0;color:#666;font-size:11px;">PayPal: terziersampurno@gmail.com — Thank you for any support.</p>
</div>
';

$table3->construct_cell($donate_html, array("colspan" => 2));
$table3->construct_row();
$table3->output("Donation");

$page->output_footer();
