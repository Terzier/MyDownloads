<?php
/***************************************************************************
 *
 *   MyDownloads plugin - Backup & Restore Module
 *   Version 4.0.1 - Fixed Restore HTTP 500
 *   Compatible with MyBB 1.8.x and PHP 8.x
 *
 ***************************************************************************/

if(!defined("IN_MYBB"))
{
	die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
}

$lang->load("mydownloads");

$page->add_breadcrumb_item(isset($lang->nav_backup) ? $lang->nav_backup : "Backup & Restore", "index.php?module=mydownloads-backup");

// ============================================================
// ACTION: Download Backup (SQL)
// ============================================================
if(isset($mybb->input['action']) && $mybb->input['action'] == "do_backup" && $mybb->request_method == "post")
{
	if(empty($mybb->usergroup['cancp']))
	{
		flash_message("Access Denied", 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	verify_post_check($mybb->get_input('my_post_key'));

	$tables = array();
	if(!empty($mybb->input['categories']))   $tables[] = "mydownloads_categories";
	if(!empty($mybb->input['log']))          $tables[] = "mydownloads_log";
	if(!empty($mybb->input['submissions']))  $tables[] = "mydownloads_submissions";
	if(!empty($mybb->input['paypal_logs']))  $tables[] = "mydownloads_paypal_logs";
	if(!empty($mybb->input['reports']))      $tables[] = "mydownloads_reports";
	if(!empty($mybb->input['tags']))         $tables[] = "mydownloads_tags";

	if(!empty($mybb->input['categories']) || !empty($mybb->input['submissions']))
	{
		$tables[] = "mydownloads_downloads";
		$tables[] = "mydownloads_comments";
		$tables[] = "mydownloads_ratings";
	}

	$tables = array_unique($tables);

	if(empty($tables))
	{
		flash_message("Please select at least one data type to backup.", 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	@set_time_limit(300);
	@ini_set('memory_limit', '256M');

	$prefix = TABLE_PREFIX;
	$sql  = "-- MyDownloads Backup generated on " . date('Y-m-d H:i:s') . "\n";
	$sql .= "-- Compatible with MyBB 1.8.x + PHP 8.x\n";
	$sql .= "-- Tables: " . implode(", ", $tables) . "\n\n";
	$sql .= "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";

	foreach($tables as $table)
	{
		$fulltable = $prefix . $table;

		// Check table exists
		$check = @$db->query("SHOW TABLES LIKE '".$db->escape_string($fulltable)."'");
		if(!$check || $db->num_rows($check) == 0)
		{
			$sql .= "-- Table {$fulltable} does not exist, skipped\n\n";
			continue;
		}

		$sql .= "-- --------------------------------------------------------\n";
		$sql .= "-- Table: `{$fulltable}`\n";
		$sql .= "-- --------------------------------------------------------\n\n";

		$query = @$db->query("SHOW CREATE TABLE `{$fulltable}`");
		if($query && $db->num_rows($query) > 0)
		{
			$create = $db->fetch_array($query);
			$create_sql = '';
			if(isset($create['Create Table']))
			{
				$create_sql = $create['Create Table'];
			}
			elseif(isset($create['Create table']))
			{
				$create_sql = $create['Create table'];
			}
			else
			{
				$vals = array_values($create);
				$create_sql = isset($vals[1]) ? $vals[1] : '';
			}

			if($create_sql)
			{
				$sql .= "DROP TABLE IF EXISTS `{$fulltable}`;\n";
				$sql .= $create_sql . ";\n\n";
			}
		}

		$sql .= "-- Data for `{$fulltable}`\n\n";

		$query = @$db->simple_select($table);
		if($query)
		{
			while($row = $db->fetch_array($query))
			{
				$fields = array();
				$values = array();
				foreach($row as $k => $v)
				{
					$fields[] = "`" . str_replace('`', '``', $k) . "`";
					if($v === null)
					{
						$values[] = "NULL";
					}
					else
					{
						$values[] = "'" . $db->escape_string($v) . "'";
					}
				}
				$sql .= "INSERT INTO `{$fulltable}` (" . implode(", ", $fields) . ") VALUES (" . implode(", ", $values) . ");\n";
			}
		}
		$sql .= "\n";
	}

	$sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

	$filename = "mydownloads_backup_" . date("Y-m-d_H-i-s") . ".sql";

	header("Content-Type: application/octet-stream");
	header("Content-Disposition: attachment; filename=\"{$filename}\"");
	header("Content-Length: " . strlen($sql));
	header("Pragma: no-cache");
	header("Expires: 0");

	echo $sql;
	exit;
}

// ============================================================
// ACTION: Restore from uploaded SQL file
// ============================================================
if(isset($mybb->input['action']) && $mybb->input['action'] == "do_restore" && $mybb->request_method == "post")
{
	if(empty($mybb->usergroup['cancp']))
	{
		flash_message("Access Denied", 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	verify_post_check($mybb->get_input('my_post_key'));

	if($mybb->get_input('confirm_restore') !== "YES")
	{
		flash_message("You must type YES (uppercase) to confirm restore.", 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	if(empty($_FILES['sqlfile']['tmp_name']) || !is_uploaded_file($_FILES['sqlfile']['tmp_name']))
	{
		$upload_err = isset($_FILES['sqlfile']['error']) ? (int)$_FILES['sqlfile']['error'] : -1;
		$msg = "No SQL file uploaded.";
		if($upload_err === 1 || $upload_err === 2)
		{
			$msg = "Uploaded file is too large. Increase upload_max_filesize / post_max_size in PHP.";
		}
		flash_message($msg, 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	$orig_name = isset($_FILES['sqlfile']['name']) ? $_FILES['sqlfile']['name'] : '';
	$ext = strtolower(pathinfo($orig_name, PATHINFO_EXTENSION));
	if($ext !== 'sql' && $ext !== 'txt')
	{
		flash_message("Only .sql or .txt files are allowed.", 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	@set_time_limit(600);
	@ini_set('memory_limit', '512M');

	$sql_content = @file_get_contents($_FILES['sqlfile']['tmp_name']);
	if($sql_content === false || strlen(trim($sql_content)) < 10)
	{
		flash_message("Could not read the uploaded file or file is empty.", 'error');
		admin_redirect("index.php?module=mydownloads-backup");
	}

	// Remove BOM if present
	if(substr($sql_content, 0, 3) === "\xEF\xBB\xBF")
	{
		$sql_content = substr($sql_content, 3);
	}

	$prefix = TABLE_PREFIX;
	$allowed_marker = "mydownloads_";

	// Parse SQL into statements (handle multi-line CREATE TABLE etc.)
	$statements = array();
	$buffer = '';
	$lines = explode("\n", $sql_content);

	foreach($lines as $line)
	{
		$trim = trim($line);

		// Skip pure comment lines
		if($trim === '' || strpos($trim, '--') === 0 || strpos($trim, '#') === 0)
		{
			continue;
		}

		// Skip block comment start-only lines
		if(strpos($trim, '/*') === 0 && strpos($trim, '*/') === false)
		{
			continue;
		}

		$buffer .= $line . "\n";

		// Statement ends with semicolon
		if(substr(rtrim($line), -1) === ';')
		{
			$stmt = trim($buffer);
			// Remove trailing semicolon for cleaner handling
			if(substr($stmt, -1) === ';')
			{
				$stmt = substr($stmt, 0, -1);
			}
			$stmt = trim($stmt);
			if($stmt !== '')
			{
				$statements[] = $stmt;
			}
			$buffer = '';
		}
	}

	// Leftover buffer
	if(trim($buffer) !== '')
	{
		$statements[] = trim($buffer);
	}

	$executed = 0;
	$skipped = 0;
	$errors = array();

	// Disable FK checks for duration of restore
	$db->query("SET FOREIGN_KEY_CHECKS=0", 1, 1);

	foreach($statements as $statement)
	{
		// Allow SET commands
		if(preg_match('/^SET\s+/i', $statement))
		{
			$db->query($statement, 1, 1);
			continue;
		}

		// Only allow specific DDL/DML on mydownloads tables
		if(!preg_match('/^(DROP\s+TABLE|CREATE\s+TABLE|INSERT\s+INTO|REPLACE\s+INTO|ALTER\s+TABLE|TRUNCATE\s+TABLE|DELETE\s+FROM|UPDATE\s+)/i', $statement))
		{
			$skipped++;
			continue;
		}

		// Safety: must reference mydownloads_ table
		if(stripos($statement, $allowed_marker) === false)
		{
			$skipped++;
			continue;
		}

		// Execute with hide_errors=1 so MyBB does NOT die on SQL error
		// Signature: query($string, $hide_errors=0, $write_query=0)
		$ok = false;
		$result = $db->query($statement, 1, 1);
		if($result !== false && $result !== null)
		{
			$executed++;
			$ok = true;
		}
		else
		{
			$err = '';
			if(method_exists($db, 'error_number') && (int)$db->error_number() > 0)
			{
				$err = method_exists($db, 'error') ? (string)$db->error() : ('SQL Error #'.$db->error_number());
			}
			if($err !== '')
			{
				$errors[] = substr($err, 0, 150);
			}
		}
	}

	// Always try to re-enable FK checks
	$db->query("SET FOREIGN_KEY_CHECKS=1", 1, 1);

	if($executed == 0 && !empty($errors))
	{
		$msg = "Restore failed. No statements executed. Error: " . htmlspecialchars($errors[0]);
		flash_message($msg, 'error');
	}
	elseif(!empty($errors))
	{
		$msg = "Restore finished with warnings. Executed: {$executed}, Skipped: {$skipped}. First error: " . htmlspecialchars($errors[0]);
		flash_message($msg, 'error');
	}
	else
	{
		flash_message("Restore successful! Executed: {$executed} statement(s), Skipped: {$skipped}.", 'success');
	}

	admin_redirect("index.php?module=mydownloads-backup");
}

// ============================================================
// Main page
// ============================================================
$page->output_header(isset($lang->nav_backup) ? $lang->nav_backup : "Backup & Restore");

echo '<div style="background:#fff3cd;border:1px solid #ffc107;padding:10px;margin-bottom:15px;border-radius:3px;">
	<strong>Warning:</strong> Restore will <u>overwrite</u> existing MyDownloads data. Always create a fresh backup first.
</div>';

// BACKUP FORM
$form = new Form("index.php?module=mydownloads-backup&amp;action=do_backup", "post");
$form_container = new FormContainer("1. Create Backup (Download SQL)");
$form_container->output_row(
	"Select data to backup",
	"Related tables (downloads, comments, ratings) are included when Categories or Submissions are selected.",
	'<div style="line-height:2;">
		<label><input type="checkbox" name="categories" value="1" checked="checked" /> Categories</label><br />
		<label><input type="checkbox" name="log" value="1" checked="checked" /> Log</label><br />
		<label><input type="checkbox" name="submissions" value="1" checked="checked" /> Submissions</label><br />
		<label><input type="checkbox" name="paypal_logs" value="1" checked="checked" /> PayPal Logs</label><br />
		<label><input type="checkbox" name="reports" value="1" checked="checked" /> Reported Items</label><br />
		<label><input type="checkbox" name="tags" value="1" checked="checked" /> Tags</label>
	</div>'
);
$form_container->end();
$buttons = array($form->generate_submit_button("Download Backup (SQL)"));
$form->output_submit_wrapper($buttons);
$form->end();

echo "<br />";

// RESTORE FORM - multipart
$form2 = new Form("index.php?module=mydownloads-backup&amp;action=do_restore", "post", "restore_form", 1);
$form_container2 = new FormContainer("2. Restore from Backup");
$form_container2->output_row(
	"SQL Backup File",
	"Upload a .sql file previously generated by this Backup tool. Max size depends on PHP upload_max_filesize.",
	$form2->generate_file_upload_box("sqlfile")
);
$form_container2->output_row(
	"Confirmation",
	'Type <strong>YES</strong> (uppercase) to confirm you want to overwrite existing data.',
	$form2->generate_text_box("confirm_restore", "", array('style' => 'width:100px;', 'placeholder' => 'YES'))
);
$form_container2->end();
$buttons2 = array($form2->generate_submit_button("Restore Now", array(
	'onclick' => "return confirm('Are you sure? This will overwrite current MyDownloads data.');"
)));
$form2->output_submit_wrapper($buttons2);
$form2->end();

$page->output_footer();
