<?php
/***************************************************************************
 *
 *   MyDownloads plugin language file
 *   Updated 2026 by Terzier
 *
 ***************************************************************************/

$l['mydownloads'] = "My Downloads";

$l['nav_about'] = "About";
$l['nav_downloads_categories'] = "Categories/Downloads";
$l['nav_log'] = "Log";
$l['nav_manage_submissions'] = "Submissions";
$l['nav_paypal'] = "PayPal Logs";
$l['nav_reports'] = "Reported Items";
$l['nav_tags'] = "Tags";
$l['nav_backup'] = "Backup & Restore";

$l['can_manage_mydownloads'] = "Can Manage MyDownloads?";
$l['can_manage_about'] = "Can view About page?";
$l['can_manage_downloads_categories'] = "Can Manage Categories & Downloads?";
$l['can_manage_log'] = "Can View Log?";
$l['can_manage_manage_submissions'] = "Can Manage Downloads Submissions?";
$l['can_manage_paypal'] = "Can Manage PayPal logs?";
$l['can_manage_reports'] = "Can Manage Reported Items?";
$l['can_manage_tags'] = "Can Manage Tags?";
$l['can_manage_backup'] = "Can Manage Backups & Restore?";
?>
